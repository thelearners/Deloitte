package com.myspr.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.myspr.beans.Staff;
import com.myspr.beans.Student;
import com.myspr.dao.StaffDao;
import com.myspr.dao.StudentDao;

@Controller
public class HomeController {

	@Autowired
	StudentDao studentDao;

	@Autowired
	StaffDao staffDao;

	@RequestMapping(value = "/")
	public String home(Model model) {
		return "searchview";
	}

	/*@RequestMapping(value = "/searchDetails")
	public String searchDetails(Model model) {
		return "searchview";
	}*/

	@RequestMapping(value = "/displayResults")
	public String displayResults(Model model, @RequestParam("category") String category,
			@RequestParam("searchSubCategory") String searchSubCategory, @RequestParam("textvalue") String textvalue) {

		model.addAttribute("category", category);
		model.addAttribute("searchSubCategory", searchSubCategory);
		model.addAttribute("textvalue", textvalue);

		if (category.equals("staff")) {
			List<Staff> staffList = null;
			if (searchSubCategory.equals("Experience")) {
				staffList = staffDao.searchByStaffExperience(Integer.parseInt(textvalue));
				System.out.println(staffList);
			} else if (searchSubCategory.equals("Salary")) {
				staffList = staffDao.searchByStaffSalary(textvalue);
			} else if (searchSubCategory.equals("Qualification")) {
				staffList = staffDao.searchByStaffQualification(textvalue);
			}
			model.addAttribute("staffList", staffList);
		} else if (category.equals("student")) {
			List<Student> studentList = null;
			studentList = studentDao.searchbyStandard(textvalue);
			model.addAttribute("studentList", studentList);
		}
		return "displayResults";
	}

}
