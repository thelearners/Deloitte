package com.myspr.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.myspr.beans.Student;

@Component
public class StudentDao {

	@Autowired
	SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public StudentDao(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}

	public StudentDao() {
	}

	@Transactional
	public void saveStudent(Student student) {
		Session session = sessionFactory.getCurrentSession();
		session.save(student);
	}

	@Transactional
	public List<Student> getstudent() {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Student");
		List<Student> students = query.list();
		return students;
	}

	@Transactional
	public List<Student> searchbyStandard(String standard) {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Student where standard=:standard");
		query.setParameter("standard", standard);
		List<Student> students = query.list();
		return students;
	}
}
