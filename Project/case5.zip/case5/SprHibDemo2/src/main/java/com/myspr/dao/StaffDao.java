package com.myspr.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.myspr.beans.Staff;

@Component
public class StaffDao {

	@Autowired
	SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public StaffDao(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}

	public StaffDao() {
	}

	@Transactional
	public void saveStaff(Staff staff) {
		//Session session = sessionFactory.getCurrentSession();
		Session session = sessionFactory.openSession();
		session.save(staff);
	}

	@Transactional
	public List<Staff> getStaff() {
		//Session session = sessionFactory.getCurrentSession();
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Staff");
		List<Staff> staff = query.list();
		return staff;
	}

	@Transactional
	public List<Staff> searchByStaffId(int staffId) {
	//	Session session = sessionFactory.getCurrentSession();
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Staff where staffId=:staffId");
		query.setParameter("staffId", staffId);
		List<Staff> staff = query.list();
		return staff;
	}

	@Transactional
	public List<Staff> searchByStaffExperience(int experience) {
		System.out.println("in DAO");
//		Session session = sessionFactory.getCurrentSession();
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Staff where experience=:experience");
		query.setParameter("experience", experience);
		List<Staff> staff = query.list();
		return staff;
	}

	@Transactional
	public List<Staff> searchByStaffQualification(String highest_qualification) {
		//Session session = sessionFactory.getCurrentSession();
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Staff where highest_qualification=:highest_qualification");
		query.setParameter("highest_qualification", highest_qualification);
		List<Staff> staff = query.list();
		return staff;
	}

	@Transactional
	public List<Staff> searchByStaffSalary(String salary) {
		//Session session = sessionFactory.getCurrentSession();
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Staff where salary=:salary");
		query.setParameter("salary", salary);
		List<Staff> staff = query.list();
		return staff;
	}

}
