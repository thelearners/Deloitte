package com.myspr.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="STUDENT_INFO")
public class Student {
	
	@Id
	String student_id;
	String Student_name;
	Date dob;
	char guardian_type;
	String guardian_name;
	String address;
	String country_id;
	long contact_no;
	String mail_id;
	char gender;
	String standard;
	char standard_category;
	char transport;
	int net_fees;
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getStudent_name() {
		return Student_name;
	}
	public void setStudent_name(String student_name) {
		Student_name = student_name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public char getGuardian_type() {
		return guardian_type;
	}
	public void setGuardian_type(char guardian_type) {
		this.guardian_type = guardian_type;
	}
	public String getGuardian_name() {
		return guardian_name;
	}
	public void setGuardian_name(String guardian_name) {
		this.guardian_name = guardian_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	
	public long getContact_no() {
		return contact_no;
	}
	public void setContact_no(long contact_no) {
		this.contact_no = contact_no;
	}
	public void setContact_no(int contact_no) {
		this.contact_no = contact_no;
	}
	public String getMail_id() {
		return mail_id;
	}
	public void setMail_id(String mail_id) {
		this.mail_id = mail_id;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public char getStandard_category() {
		return standard_category;
	}
	public void setStandard_category(char standard_category) {
		this.standard_category = standard_category;
	}
	public char getTransport() {
		return transport;
	}
	public void setTransport(char transport) {
		this.transport = transport;
	}
	public int getNet_fees() {
		return net_fees;
	}
	public void setNet_fees(int net_fees) {
		this.net_fees = net_fees;
	}
	public Student(String student_id, String student_name, Date dob, char guardian_type, String guardian_name,
			String address, String country_id, int contact_no, String mail_id, char gender, String standard,
			char standard_category, char transport, int net_fees) {
		super();
		this.student_id = student_id;
		Student_name = student_name;
		this.dob = dob;
		this.guardian_type = guardian_type;
		this.guardian_name = guardian_name;
		this.address = address;
		this.country_id = country_id;
		this.contact_no = contact_no;
		this.mail_id = mail_id;
		this.gender = gender;
		this.standard = standard;
		this.standard_category = standard_category;
		this.transport = transport;
		this.net_fees = net_fees;
	}
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [student_id=" + student_id + ", Student_name=" + Student_name + ", dob=" + dob
				+ ", guardian_type=" + guardian_type + ", guardian_name=" + guardian_name + ", address=" + address
				+ ", country_id=" + country_id + ", contact_no=" + contact_no + ", mail_id=" + mail_id + ", gender="
				+ gender + ", standard=" + standard + ", standard_category=" + standard_category + ", transport="
				+ transport + ", net_fees=" + net_fees + "]";
	}
	
	
	
	
	
}
