package com.myspr.beans;

import java.util.Date;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="STAFF_INFO")

public class Staff {
	@Id
	String staff_id;
	String staff_name;
	Date dob;
	String address;
	String country_id;
	char gender;
	long salary;
	String highest_qualification;
	String email_id;
	String contact_number;
	String designation;
	int year_passed_out;
	int experience;
	Date doj;
	public String getStaff_id() {
		return staff_id;
	}
	public void setStaff_id(String staff_id) {
		this.staff_id = staff_id;
	}
	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	public String getHighest_qualification() {
		return highest_qualification;
	}
	public void setHighest_qualification(String highest_qualification) {
		this.highest_qualification = highest_qualification;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getContact_number() {
		return contact_number;
	}
	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getYear_passed_out() {
		return year_passed_out;
	}
	public void setYear_passed_out(int year_passed_out) {
		this.year_passed_out = year_passed_out;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public Staff(String staff_id, String staff_name, Date dob, String address, String country_id, char gender,
			long salary, String highest_qualification, String email_id, String contact_number, String designation,
			int year_passed_out, int experience, Date doj) {
		super();
		this.staff_id = staff_id;
		this.staff_name = staff_name;
		this.dob = dob;
		this.address = address;
		this.country_id = country_id;
		this.gender = gender;
		this.salary = salary;
		this.highest_qualification = highest_qualification;
		this.email_id = email_id;
		this.contact_number = contact_number;
		this.designation = designation;
		this.year_passed_out = year_passed_out;
		this.experience = experience;
		this.doj = doj;
	}
	public Staff() {
		super();
	}
	
	
	
}
